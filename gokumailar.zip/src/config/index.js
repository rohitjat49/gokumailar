export const apiUrl = "https://api.gokumailer.store/api";
